Rewritto-ide (native Linux binary)

Run:
  ./rewritto-ide

Notes:
- Use the same machine profile used for building (Linux x86_64).
- For a fully bundled package with dependencies, use the AppImage artifact.
- If present, the bundled ./arduino-cli will be auto-detected by rewritto-ide.
